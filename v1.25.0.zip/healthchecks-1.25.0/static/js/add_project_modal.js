$(function () {
    $("#add-project-modal").on('shown.bs.modal', function () {
        $("#add-project-name").focus();
    })
});