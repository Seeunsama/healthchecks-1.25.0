$(function () {
    $("#tz").val(Intl.DateTimeFormat().resolvedOptions().timeZone);
});
